package com.example.example;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v7.app.AppCompatActivity;
import android.widget.*;


public class ConverterFragment extends Fragment implements View.OnClickListener{

    private Spinner spinner, spinner2, spinner3;
    private Button convert;
    private EditText text1, text2;
    private int pos1;
    private double val1, val2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_converter, null );
        spinner = (Spinner) view.findViewById(R.id.spinner);
        spinner2 = (Spinner) view.findViewById(R.id.spinner2);
        spinner3 = (Spinner) view.findViewById(R.id.spinner3);
        convert = (Button) view.findViewById(R.id.button);
        text1 = (EditText)view.findViewById(R.id.editText2);
        text2 = (EditText)view.findViewById(R.id.editText3);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(view.getContext(), R.layout.support_simple_spinner_dropdown_item, getResources().getStringArray(R.array.options));
        spinner.setAdapter(adapter);

        final ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(view.getContext(), R.layout.support_simple_spinner_dropdown_item, getResources().getStringArray(R.array.length));
        spinner2.setAdapter(adapter2);
        spinner3.setAdapter(adapter2);

        final ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(view.getContext(), R.layout.support_simple_spinner_dropdown_item, getResources().getStringArray(R.array.temperature));
        final ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(view.getContext(), R.layout.support_simple_spinner_dropdown_item, getResources().getStringArray(R.array.mass));
        final ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(view.getContext(), R.layout.support_simple_spinner_dropdown_item, getResources().getStringArray(R.array.volume));

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                switch(position){

                    case 0:
                        spinner2.setAdapter(adapter2);
                        spinner3.setAdapter(adapter2);
                        Length();
                        break;
                    case 1:
                        spinner2.setAdapter(adapter3);
                        spinner3.setAdapter(adapter3);
                        Temperature();
                        break;
                    case 2:
                        spinner2.setAdapter(adapter4);
                        spinner3.setAdapter(adapter4);
                        Mass();
                        break;
                    case 3:
                        spinner2.setAdapter(adapter5);
                        spinner3.setAdapter(adapter5);
                        Volume();
                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        convert.setOnClickListener(this);

        return view;

    }

    public void Length(){

        text1.setText("0.0");

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                switch(position){

                    case 0:
                        pos1 = 0;
                        break;
                    case 1:
                        pos1 = 1;
                        break;
                    case 2:
                        pos1 = 2;
                        break;
                    case 3:
                        pos1 = 3;
                        break;
                    case 4:
                        pos1 = 4;
                        break;
                    case 5:
                        pos1 = 5;
                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }
        });


        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                val1 = Double.parseDouble(text1.getText().toString());

                switch(position){

                    case 0:
                        if(pos1 == 0){


                            val2 = val1;

                        }

                        else if(pos1 == 1){


                            val2 = val1 * 12;

                        }

                        else if(pos1==2){


                            val2 = val1 * 36;

                        }

                        else if(pos1==3){


                            val2 = val1 / 2.54;

                        }

                        else if(pos1==4){


                            val2 = val1 * 39.37;

                        }

                        else if(pos1==5){


                            val2 = val1 * 39370.079;

                        }

                        break;
                    case 1:
                        if(pos1 == 0){


                            val2 = val1 / 12;

                        }

                        else if(pos1 == 1){


                            val2 = val1;

                        }

                        else if(pos1==2){


                            val2 = val1 * 3;

                        }

                        else if(pos1==3){


                            val2 = val1 / 30.48;

                        }

                        else if(pos1==4){


                            val2 = val1 * 3.281;

                        }

                        else if(pos1==5){


                            val2 = val1 * 3280.84;

                        }

                        break;
                    case 2:

                        if(pos1 == 0){


                            val2 = val1 / 36;

                        }

                        else if(pos1 == 1){


                            val2 = val1 / 3;

                        }

                        else if(pos1==2){


                            val2 = val1;

                        }

                        else if(pos1==3){


                            val2 = val1 / 91.44;

                        }

                        else if(pos1==4){


                            val2 = val1 * 1.094;

                        }

                        else if(pos1==5){


                            val2 = val1 * 1093.613;

                        }

                        break;

                    case 3:

                        if(pos1 == 0){


                            val2 = val1 * 2.54;

                        }

                        else if(pos1 == 1){


                            val2 = val1 * 30.48;

                        }

                        else if(pos1==2){


                            val2 = val1 * 91.44;

                        }

                        else if(pos1==3){


                            val2 = val1;

                        }

                        else if(pos1==4){


                            val2 = val1 * 100;

                        }

                        else if(pos1==5){


                            val2 = val1 * 100000;

                        }

                        break;
                    case 4:

                        if(pos1 == 0){


                            val2 = val1 /39.37;

                        }

                        else if(pos1 == 1){


                            val2 = val1 / 3.281;

                        }

                        else if(pos1==2){


                            val2 = val1 / 1.094;

                        }

                        else if(pos1==3){


                            val2 = val1 / 100;

                        }

                        else if(pos1==4){


                            val2 = val1;

                        }

                        else if(pos1==5){


                            val2 = val1 * 1000;

                        }

                        break;
                    case 5:

                        if(pos1 == 0){


                            val2 = val1 /39370.079;

                        }

                        else if(pos1 == 1){


                            val2 = val1 / 3280.84;

                        }

                        else if(pos1==2){


                            val2 = val1 / 1093.613;

                        }

                        else if(pos1==3){


                            val2 = val1 / 100000;

                        }

                        else if(pos1==4){


                            val2 = val1 / 1000;

                        }

                        else if(pos1==5){


                            val2 = val1;

                        }

                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent){

            }


        });

    }

    public void Temperature(){

        text1.setText("0.0");

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                switch(position){

                    case 0:
                        pos1 = 0;
                        break;
                    case 1:
                        pos1 = 1;
                        break;
                    case 2:
                        pos1 = 2;
                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }
        });


        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                val1 = Double.parseDouble(text1.getText().toString());

                switch(position){

                    case 0:
                        if(pos1 == 0){


                            val2 = val1;

                        }

                        else if(pos1 == 1){


                            val2 = (val1 - 32) * (5.0/9.0);

                        }

                        else if(pos1==2){


                            val2 = val1 - 273.15;

                        }

                        break;
                    case 1:
                        if(pos1 == 0){


                            val2 = (val1 * 1.8) + 32;

                        }

                        else if(pos1 == 1){


                            val2 = val1;

                        }

                        else if(pos1==2){


                            val2 = (val1 - 273.15) * 1.8 + 32;

                        }

                        break;
                    case 2:

                        if(pos1 == 0){


                            val2 = val1 + 273.15;

                        }

                        else if(pos1 == 1){


                            val2 = (val1 - 32) * (5.0/9.0) + 273.15;

                        }

                        else if(pos1==2){


                            val2 = val1;

                        }

                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent){

            }


        });

    }

    public void Mass(){

        text1.setText("0.0");

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                switch(position){

                    case 0:
                        pos1 = 0;
                        break;
                    case 1:
                        pos1 = 1;
                        break;
                    case 2:
                        pos1 = 2;
                        break;
                    case 3:
                        pos1 = 3;
                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }
        });


        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                val1 = Double.parseDouble(text1.getText().toString());

                switch(position){

                    case 0:
                        if(pos1 == 0){


                            val2 = val1;

                        }

                        else if(pos1 == 1){


                            val2 = val1 / 16;

                        }

                        else if(pos1==2){


                            val2 = val1 / 453.592;

                        }

                        else if(pos1==3){


                            val2 = val1 * 2.205;

                        }

                        break;
                    case 1:
                        if(pos1 == 0){


                            val2 = val1 * 16;

                        }

                        else if(pos1 == 1){


                            val2 = val1;

                        }

                        else if(pos1==2){


                            val2 = val1 / 28.35;

                        }

                        else if(pos1==3){


                            val2 = val1 * 35.274;

                        }

                        break;
                    case 2:

                        if(pos1 == 0){


                            val2 = val1 * 453.592;

                        }

                        else if(pos1 == 1){


                            val2 = val1 * 28.35;

                        }

                        else if(pos1==2){


                            val2 = val1;

                        }

                        else if(pos1==3){


                            val2 = val1 * 1000;

                        }

                        break;

                    case 3:

                        if(pos1 == 0){


                            val2 = val1 / 2.205;

                        }

                        else if(pos1 == 1){


                            val2 = val1 / 35.274;

                        }

                        else if(pos1==2){


                            val2 = val1 / 1000;

                        }

                        else if(pos1==3){


                            val2 = val1;

                        }

                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent){

            }


        });

    }

    public void Volume(){

        text1.setText("0.0");

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                switch(position){

                    case 0:
                        pos1 = 0;
                        break;
                    case 1:
                        pos1 = 1;
                        break;
                    case 2:
                        pos1 = 2;
                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }
        });


        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                val1 = Double.parseDouble(text1.getText().toString());

                switch(position){

                    case 0:
                        if(pos1 == 0){


                            val2 = val1;

                        }

                        else if(pos1 == 1){


                            val2 = val1 / 1000;

                        }

                        else if(pos1==2){


                            val2 = val1 * 3.785;

                        }

                        break;
                    case 1:
                        if(pos1 == 0){


                            val2 = val1 * 1000;

                        }

                        else if(pos1 == 1){


                            val2 = val1;

                        }

                        else if(pos1==2){


                            val2 = val1 * 3785.412;

                        }

                        break;
                    case 2:

                        if(pos1 == 0){


                            val2 = val1 / 3.785;

                        }

                        else if(pos1 == 1){


                            val2 = val1 /  3785.412;

                        }

                        else if(pos1==2){


                            val2 = val1;

                        }

                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent){

            }

        });

    }

    @Override
    public void onClick(View view) {

        text2.setText(val2 + "");

    }


}
