package com.example.example;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class CalculatorFragment extends Fragment{

    private Button button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16, button17, button18, button19, button20, button21, button22, button23, button24, button25, button26, button27, button28, button29, button30, button31, button32, button33, button34, button35, button36;
    private EditText result;
    private TextView output;
    private double val1, val2;
    private boolean add, sub, mul, div, pow;

    //DegRad
    private Switch switch1;
    private double ans1 = 0;
    private double ans2 = 0;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_calculator, null);

        result = (EditText) view.findViewById(R.id.editText);
        output = (TextView) view.findViewById(R.id.textView);

        switch1 = view.findViewById(R.id.switch1);
        button3 = (Button) view.findViewById(R.id.button3);
        button4 = (Button) view.findViewById(R.id.button4);
        button5 = (Button) view.findViewById(R.id.button5);
        button6 = (Button) view.findViewById(R.id.button6);
        button7 = (Button) view.findViewById(R.id.button7);
        button8 = (Button) view.findViewById(R.id.button8);
        button9 = (Button) view.findViewById(R.id.button9);
        button10 = (Button) view.findViewById(R.id.button10);
        button11 = (Button) view.findViewById(R.id.button11);
        button12 = (Button) view.findViewById(R.id.button12);
        button13 = (Button) view.findViewById(R.id.button13);
        button14 = (Button) view.findViewById(R.id.button14);
        button15 = (Button) view.findViewById(R.id.button15);
        button16 = (Button) view.findViewById(R.id.button16);
        button17 = (Button) view.findViewById(R.id.button17);
        button18 = (Button) view.findViewById(R.id.button18);
        button19 = (Button) view.findViewById(R.id.button19);
        button20 = (Button) view.findViewById(R.id.button20);
        button21 = (Button) view.findViewById(R.id.button21);
        button22 = (Button) view.findViewById(R.id.button22);
        button23 = (Button) view.findViewById(R.id.button23);
        button24 = (Button) view.findViewById(R.id.button24);
        button25 = (Button) view.findViewById(R.id.button25);
        button26 = (Button) view.findViewById(R.id.button26);
        button27 = (Button) view.findViewById(R.id.button27);
        button28 = (Button) view.findViewById(R.id.button28);
        button29 = (Button) view.findViewById(R.id.button29);
        button30 = (Button) view.findViewById(R.id.button30);
        button31 = (Button) view.findViewById(R.id.button31);
        button32 = (Button) view.findViewById(R.id.button32);
        button33 = (Button) view.findViewById(R.id.button33);
        button34 = (Button) view.findViewById(R.id.button34);
        button35 = (Button) view.findViewById(R.id.button35);
        button36 = (Button) view.findViewById(R.id.button36);

            //Clear
            button3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.setText("");
                    result.setText("");
                }
            });

            button15.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("7");
                    result.append("7");
                }
            });

            button16.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("8");
                    result.append("8");
                }
            });

            button17.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("9");
                    result.append("9");
                }
            });

            button21.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("4");
                    result.append("4");
                }
            });

            button22.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("5");
                    result.append("5");
                }
            });

            button23.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("6");
                    result.append("6");
                }
            });

            button27.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("1");
                    result.append("1");
                }
            });

            button28.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("2");
                    result.append("2");
                }
            });

            button29.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("3");
                    result.append("3");
                }
            });

            button34.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("0");
                    result.append("0");
                }
            });

            //x^2
            button14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("^2");
                    result.setText(Math.pow(Double.parseDouble(result.getText().toString()), 2) + "");
                }
            });

            //x^y
            button19.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    val1 = Double.parseDouble(result.getText().toString());
                    output.append("^");
                    result.setText(null);
                    pow = true;


                }
            });

            //%
            button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("%");
                    result.setText((Double.parseDouble(result.getText().toString()) * .01) + "");
                }
            });

            //2^x
            button7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    output.setText("2^" + result.getText().toString());
                    result.setText(Math.pow(2, Double.parseDouble(result.getText().toString())) + "");
                }
            });

            //sqrt
            button8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.setText("√" + result.getText().toString() + "");
                    result.setText(Math.sqrt(Double.parseDouble(result.getText().toString())) + "");
                }
            });

            //1/x
            button20.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append(" 1 / ");
                    val1 = 1;
                    div = true;
                    result.setText(null);

                }

            });

            //abs
            button13.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.setText("|" + result.getText().toString() + "|");
                    result.setText(Math.abs(Double.parseDouble(result.getText().toString())) + "");
                }
            });

            //E
            button31.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                        output.setText("" + Math.E);
                        result.setText("" + Math.E);

                    }

            });

            //PI
            button32.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                        output.setText("" + Math.PI);
                        result.setText("" + Math.PI);

                }

            });

            //Radian and Degree Switch:
            switch1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(switch1.isChecked() == true) {

                        switch1.setText("Degree");

                    }
                    else if(switch1.isChecked() == false){

                        switch1.setText("Radian");

                    }

                }
            });



            //SIN:
            button9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(switch1.isChecked() == false) {
                        output.setText("sin(" + result.getText().toString() + ")");
                        result.setText(Math.sin(Double.parseDouble(result.getText().toString())) + "");
                    }
                    else{

                        output.setText("sin(" + result.getText().toString() + ")");
                        ans1 = Double.parseDouble(result.getText().toString());
                        ans2 = (ans1 * 0.0174533);

                        result.setText(""+Math.sin(ans2));


                    }



                }
            });

            //COS:
            button10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(switch1.isChecked() == false) {
                        output.setText("cos(" + result.getText().toString() + ")");
                        result.setText(Math.cos(Double.parseDouble(result.getText().toString())) + "");
                    }
                    else{

                        output.setText("cos(" + result.getText().toString() + ")");
                        ans1 = Double.parseDouble(result.getText().toString());
                        ans2 = (ans1 * 0.0174533);

                        result.setText(""+Math.cos(ans2));


                    }

                }
            });

            //TAN:
            button11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(switch1.isChecked() == false) {
                        output.setText("tan(" + result.getText().toString() + ")");
                        result.setText(Math.tan(Double.parseDouble(result.getText().toString())) + "");
                    }
                    else{

                        output.setText("tan(" + result.getText().toString() + ")");
                        ans1 = Double.parseDouble(result.getText().toString());
                        ans2 = (ans1 * 0.0174533);

                        result.setText(""+Math.tan(ans2));


                    }

                }
            });


            //ln
            button26.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.setText("ln(" + result.getText().toString() + ")");
                    result.setText(Math.log( Double.parseDouble(result.getText().toString()) ) + "");

                }
            });

            //log
            button25.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.setText("log(" + result.getText().toString() + ")");
                    result.setText(Math.log10( Double.parseDouble(result.getText().toString()) ) + "");

                }
            });

            //(
            button5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("(");

                }
            });

            //)
            button6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append(")");

                }
            });

            //decimal
            button35.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append(".");
                    result.append(".");
                }
            });


            //negative
            button33.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append("-");
                    result.append("-");
                }
            });

            //addition
            button12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append(" + ");
                    val1 = Double.parseDouble(result.getText().toString());
                    add = true;
                    result.setText(null);

                }

            });

            //subtraction
            button18.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    output.append(" - ");
                    val1 = Double.parseDouble(result.getText().toString());
                    sub = true;
                    result.setText(null);

                }

            });

            //multiplication
            button24.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append(" * ");
                    val1 = Double.parseDouble(result.getText().toString());
                    mul = true;
                    result.setText(null);

                }

            });

            //division
            button30.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    output.append(" / ");
                    val1 = Double.parseDouble(result.getText().toString());
                    div = true;
                    result.setText(null);

                }

            });

            //equal
            button36.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    val2 = Double.parseDouble(result.getText().toString());

                    if (add == true) {
                        result.setText(val1 + val2 + "");
                        add = false;
                    }

                    if (sub == true) {
                        result.setText(val1 - val2 + "");
                        sub = false;
                    }

                    if (mul == true) {
                        result.setText(val1 * val2 + "");
                        mul = false;
                    }

                    if (div == true) {

                        result.setText(val1 / val2 + "");
                        div = false;

                    }

                    if (pow == true) {

                        result.setText(Math.pow(val1, val2) + "");
                        pow = false;
                    }

                    output.setText(result.getText().toString());

                }

            });


        return view;

    }

}
