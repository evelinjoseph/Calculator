package com.example.example;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;


public class GraphFragment extends Fragment {

    private Button button37, button38, button39, button40, button41, button42, button43, button44, button45, button46, button47, button48, button49, button50, button51, button52, button53, button54, button55, button56, button57, button58, button59, button60, button61, button62, button63, button64, button65;
    LineGraphSeries<DataPoint> series;
    private EditText y1;
    private String val1, val2, equation;
    private boolean add, sub, mul, div, sin, cos, tan;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_graph, null );

        button37 = (Button) view.findViewById(R.id.button37);
        button38 = (Button) view.findViewById(R.id.button38);
        button39 = (Button) view.findViewById(R.id.button39);
        button40 = (Button) view.findViewById(R.id.button40);
        button41 = (Button) view.findViewById(R.id.button41);
        button42 = (Button) view.findViewById(R.id.button42);
        button43 = (Button) view.findViewById(R.id.button43);
        button44 = (Button) view.findViewById(R.id.button44);
        button45 = (Button) view.findViewById(R.id.button45);
        button46 = (Button) view.findViewById(R.id.button46);
        button47 = (Button) view.findViewById(R.id.button47);
        button48 = (Button) view.findViewById(R.id.button48);
        button49 = (Button) view.findViewById(R.id.button49);
        button50 = (Button) view.findViewById(R.id.button50);
        button51 = (Button) view.findViewById(R.id.button51);
        button52 = (Button) view.findViewById(R.id.button52);
        button53 = (Button) view.findViewById(R.id.button53);
        button54 = (Button) view.findViewById(R.id.button54);
        button55 = (Button) view.findViewById(R.id.button55);
        button56 = (Button) view.findViewById(R.id.button56);
        button57 = (Button) view.findViewById(R.id.button57);
        button58 = (Button) view.findViewById(R.id.button58);
        button59 = (Button) view.findViewById(R.id.button59);
        button60 = (Button) view.findViewById(R.id.button60);
        button61 = (Button) view.findViewById(R.id.button61);
        button62 = (Button) view.findViewById(R.id.button62);
        button63 = (Button) view.findViewById(R.id.button63);
        button64 = (Button) view.findViewById(R.id.button64);
        button65 = (Button) view.findViewById(R.id.button65);

        final GraphView graph = (GraphView) view.findViewById(R.id.graph) ;
        y1 = (EditText) view.findViewById(R.id.editText4) ;

        //Clear
        button37.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.setText("");
                equation = "";


            }
        });

        button40.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("7");
                equation += "7";

            }
        });

        button41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("8");
                equation += "8";

            }
        });

        button42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("9");
                equation += "9";

            }
        });

        button47.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("4");
                equation += "4";
            }
        });

        button48.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("5");
                equation += "5";
            }
        });

        button49.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("6");
                equation += "6";
            }
        });

        button54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("1");
                equation += "1";
            }
        });

        button55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("2");
                equation += "2";
            }
        });

        button56.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("3");
                equation += "3";
            }
        });

        button62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("0");
                equation += "0";
            }
        });

        //(
        button38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("(");

            }
        });

        //)
        button39.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append(")");

            }
        });

        //x
        button44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("x");
                equation += "x";
            }
        });

        //decimal
        button63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append(".");
                equation += ".";
            }
        });


        //negative
        button61.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("-");
                equation += "-";
            }
        });

        //addition
        button43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                val1 = y1.getText().toString();
                y1.append(" + ");
                add = true;
                equation = "";

            }

        });

        //subtraction
        button50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                val1 = y1.getText().toString();
                y1.append(" - ");
                sub = true;
                equation = "";

            }

        });

        //multiplication
        button57.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                val1 = y1.getText().toString();
                y1.append(" * ");

                mul = true;
                equation = "";

            }

        });

        //division
        button64.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                val1 = y1.getText().toString();
                y1.append(" / ");
                div = true;
                equation = "";

            }

        });

        //sin
        button58.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("SIN(");
                sin = true;
                equation = "";

            }

        });

        //cos
        button59.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("COS(");
                cos = true;
                equation = "";

            }

        });

        //tan
        button60.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                y1.append("TAN(");
                tan = true;
                equation = "";

            }

        });

        //graph
        button65.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double y,x, num;
                x = -10.0;

                series = new LineGraphSeries<DataPoint>();

                val2 = equation;

                if(y1.getText().toString().equals("x")){

                    for(int i = 0; i<10000; i++){

                        x += 0.01;
                        y = x;
                        series.appendData(new DataPoint(x, y), true, 10000);
                    }

                    graph.addSeries(series);

                }

                if(sin == true){


                    for(int i = 0; i<10000; i++){

                        x += 0.01;
                        y = Math.sin(x);
                        series.appendData(new DataPoint(x, y), true, 10000);


                    }

                    // set manual X bounds
                    graph.getViewport().setYAxisBoundsManual(true);
                    graph.getViewport().setMinY(-150);
                    graph.getViewport().setMaxY(150);

                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(-10);
                    graph.getViewport().setMaxX(80);

                    // enable scaling and scrolling
                    graph.getViewport().setScalable(true);
                    graph.getViewport().setScalableY(true);

                    graph.addSeries(series);
                    sin = false;

                }

                if(cos == true){


                    for(int i = 0; i<10000; i++){

                        x += 0.01;
                        y = Math.cos(x);
                        series.appendData(new DataPoint(x, y), true, 10000);


                    }

                    // set manual X bounds
                    graph.getViewport().setYAxisBoundsManual(true);
                    graph.getViewport().setMinY(-150);
                    graph.getViewport().setMaxY(150);

                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(-10);
                    graph.getViewport().setMaxX(80);

                    // enable scaling and scrolling
                    graph.getViewport().setScalable(true);
                    graph.getViewport().setScalableY(true);

                    graph.addSeries(series);
                    cos = false;

                }

                if(tan == true){

                    x = -1.0;
                    for(int i = 0; i<10000; i++){

                        x += 0.01;
                        y = Math.tan(x);
                        series.appendData(new DataPoint(x, y), true, 10000);


                    }

                    // set manual X bounds
                    graph.getViewport().setYAxisBoundsManual(true);
                    graph.getViewport().setMinY(-150);
                    graph.getViewport().setMaxY(150);

                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(-10);
                    graph.getViewport().setMaxX(80);

                    // enable scaling and scrolling
                    graph.getViewport().setScalable(true);
                    graph.getViewport().setScalableY(true);

                    graph.addSeries(series);
                    tan = false;

                }


                if (add == true) {

                    if(val1.equals("x"))
                    {

                        num = Double.parseDouble(val2);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = x + num;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }


                    }

                    else if(val2.equals("x"))
                    {

                        num = Double.parseDouble(val1);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = num + x;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }
                    }

                    else
                    {


                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = Double.parseDouble(val1) + Double.parseDouble(val2);
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }



                    }

                    // set manual X bounds
                    graph.getViewport().setYAxisBoundsManual(true);
                    graph.getViewport().setMinY(-150);
                    graph.getViewport().setMaxY(150);

                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(-10);
                    graph.getViewport().setMaxX(80);

                    // enable scaling and scrolling
                    graph.getViewport().setScalable(true);
                    graph.getViewport().setScalableY(true);
                    graph.addSeries(series);
                    add = false;
                }

                if (sub == true) {

                    if(val1.equals("x"))
                    {

                        num = Double.parseDouble(val2);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = x - num;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }


                    }

                    else if(val2.equals("x"))
                    {

                        num = Double.parseDouble(val1);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = num - x;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }
                    }

                    else
                    {


                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = Double.parseDouble(val1) - Double.parseDouble(val2);
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }



                    }

                    // set manual X bounds
                    graph.getViewport().setYAxisBoundsManual(true);
                    graph.getViewport().setMinY(-150);
                    graph.getViewport().setMaxY(150);

                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(-10);
                    graph.getViewport().setMaxX(80);

                    // enable scaling and scrolling
                    graph.getViewport().setScalable(true);
                    graph.getViewport().setScalableY(true);
                    graph.addSeries(series);
                    sub = false;
                }

                if (mul == true) {

                    if(val1.equals("x"))
                    {

                        num = Double.parseDouble(val2);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = x * num;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }


                    }

                    else if(val2.equals("x"))
                    {

                        num = Double.parseDouble(val1);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = num * x;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }
                    }

                    else
                    {


                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = Double.parseDouble(val1) * Double.parseDouble(val2);
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }



                    }

                    // set manual X bounds
                    graph.getViewport().setYAxisBoundsManual(true);
                    graph.getViewport().setMinY(-150);
                    graph.getViewport().setMaxY(150);

                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(-10);
                    graph.getViewport().setMaxX(80);

                    // enable scaling and scrolling
                    graph.getViewport().setScalable(true);
                    graph.getViewport().setScalableY(true);
                    graph.addSeries(series);
                    mul = false;
                }

                if (div == true) {

                    if(val1.equals("x"))
                    {

                        num = Double.parseDouble(val2);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = x / num;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }


                    }

                    else if(val2.equals("x"))
                    {

                        num = Double.parseDouble(val1);
                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = num / x;
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }
                    }

                    else
                    {


                        for(int i = 0; i<10000; i++){

                            x += 0.01;
                            y = Double.parseDouble(val1) / Double.parseDouble(val2);
                            series.appendData(new DataPoint(x, y), true, 10000);


                        }



                    }

                    // set manual X bounds
                    graph.getViewport().setYAxisBoundsManual(true);
                    graph.getViewport().setMinY(-150);
                    graph.getViewport().setMaxY(150);

                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(-10);
                    graph.getViewport().setMaxX(80);

                    // enable scaling and scrolling
                    graph.getViewport().setScalable(true);
                    graph.getViewport().setScalableY(true);
                    graph.addSeries(series);

                    div = false;

                }

            }

        });

        return view;

    }
}
